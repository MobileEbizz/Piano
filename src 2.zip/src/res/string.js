export const Strings = {
    ENTER_VALID_PHONE_NUMBER: "Invalid number. Please try again.",
    INVALID_OTP: "Incorrect code. Please try again.",
    INVALID_AGE: "You must be 18 years\nold to use Vove.",
    NETWORK_ISSUE: "No connection, Please try again",
    SEARCH_LOCATION: "Search locations",
    ENABLE_LOCATION_SERVICE: "Please enable location service."
}