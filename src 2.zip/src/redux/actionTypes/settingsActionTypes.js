export const USER_DETAILS = "USER_DETAILS";
export const IS_IAP_MODAL = "IS_IAP_MODAL";
export const ON_GET_CHAT = "ON_GET_CHAT";
export const IS_UPGRADE_MODAL = "IS_UPGRADE_MODAL";
export const ON_BEGIN_CLICKED = "ON_BEGIN_CLICKED";